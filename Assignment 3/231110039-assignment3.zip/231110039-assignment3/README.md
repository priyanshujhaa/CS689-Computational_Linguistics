ASSIGNMENT 3- COMPUTATIONAL LINGUISTICS FOR INDIAN LANGUAGES
PRIYANSHU KUMAR JHA
231110039

MOTHER TONGUE X: HINDI
LANGUAGE Y: MARATHI

-> SOLUTIONS TO QUESTION 1, QUESTION 2 AND QUESTION 3 ARE PROVIDED IN THREE DIFFERENT FOLDERS.

-> DIFFERENT MODELS ARE USED FOR TRANSLATION IN DIFFERENT NOTEBOOKS NAMED AS:
nllb.ipynb
indicTrans.ipynb
FOR CHATGPT ONLY THE TRANSLATIONS ARE PROVIDED WHICH WAS OBTAINED BY PASSING THE SENTENCES IN PROMPT TO CHATGPT

-> Folder 'chatGPT' contains output translations produced by chatgpt and 100 input sentences provided to it. 

-> Folder 'indicTrans' contains output translations produced by indicTrans. 

-> Folder 'nllb' contains output translations produced by nllb. 

-> Inputs given to nllb and indicTrans were 1000 random sentences from samantar dataset's test files, these are provided with the assignment and are named as:
test.en_1000
test.hi_1000
test.mr_1000



