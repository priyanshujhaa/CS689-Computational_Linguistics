ASSIGNMENT 2- COMPUTATIONAL LINGUISTICS FOR INDIAN LANGUAGES

NAME: PRIYANSHU KUMAR JHA
ROLL NUMBER: 231110039

LANGUAGE TAKEN: HINDI

The assignment responses are organized into distinct directories. The overall conclusion for the assignment can be located within the finalized detailed report contained in the "Question 5" folder.

In addressing Question 1, manual NER tagging was undertaken for the provided set of 25 sentences.

For Question 2, the focus was on fine-tuning the pretrained models indicBERT and indicNER on the naamapadam corpus, exploring a variety of hyperparameters, and subsequently reporting the attained metrics. Each model's outputs are documented in their respective notebooks.

Question 3 involved providing 25 sentences as input prompts to ChatGPT, along with the 9 NER classes, and then recording the generated outputs.

Question 4 revolved around calculating precision, recall, and F1-score for both models and ChatGPT, comparing their performance against the manually annotated sentences from Question 1.

Finally, in addressing Question 5, a thorough report was compiled, encompassing model comparisons, hyperparameter details, model outputs, and additional noteworthy observations.